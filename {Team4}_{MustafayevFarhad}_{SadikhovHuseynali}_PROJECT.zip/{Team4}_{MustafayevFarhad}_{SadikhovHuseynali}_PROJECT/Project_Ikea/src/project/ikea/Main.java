package project.ikea;

import project.ikea.operations.*;
import project.ikea.pojo.Product;
import project.ikea.pojo.util.CSVUtil;
import project.ikea.pojo.util.ProductUtil;

import java.lang.reflect.Field;
import java.util.*;

public class Main {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        CSVUtil csvUtil = new CSVUtil();
        //CSV Util to take care of csv file related operations , ie read file, write file

        // Util file for operations like splittng the columns, sleecting random records
        ProductUtil processingUtil = new ProductUtil();

        //Read the file and data processing
        List<Product> productsFromCSV = csvUtil.readCSV("ikea.csv");
        menu(productsFromCSV);

    }

    public  static void menu(List<Product> productsFromCSV){
        ListOperations listOperations = new ListOperations();
        SortOperations sortOperations = new SortOperations();
        SearchOperations searchOperations= new SearchOperations();
        ColumnOperations columnOperations = new ColumnOperations();
        FilterOperations filterOperations = new FilterOperations();
        ExportOperations exportOperations = new ExportOperations();
        CSVUtil csvUtil = new CSVUtil();

        List<Product> selectedList = new ArrayList<>();
        selectedList.addAll(productsFromCSV);

        while(true) {
            System.out.println("******************* Menu *****************");
            //System.out.println("0. Display entities");
            System.out.println("1. List All entities");
            System.out.println("2. Sort entities");
            System.out.println("3. Search entities");
            System.out.println("4. List Column names");
            System.out.println("5. Filter entities");
            System.out.println("6. Export Whole List of Designers");
            System.out.println("7. Export Products for each Category");
            System.out.println("0. Press 0 to exit");

            int option = sc.nextInt();
            if (option == 0) {
                break;
            }

            try {
                switch (option) {
                    case 1:
                        selectedList = listOperations.listMenu(productsFromCSV);
                        listOperations.printSelectedList(selectedList);
                        break;
                    case 2:
                        sortOperations.sort(selectedList);
                        listOperations.printSelectedList(selectedList);
                        break;
                    case 3:
                        System.out.print("Search Field : ");
                        System.out.println(columnOperations.getColumnNames());
                        System.out.println();
                        String searchField = sc.next();

                        System.out.print("Search Value : ");
                        String searchValue = sc.next();

                        selectedList = searchOperations.search(selectedList, searchField, searchValue);
                        List<String> searchColumnList = listOperations.printSelectedList(selectedList);
                        System.out.println("Export to csv? (Y/N)");
                        String searchExport = sc.next();
                        exportCSV(csvUtil, searchExport, selectedList, searchColumnList, "search_" + searchField + "_" + searchValue);
                        break;
                    case 4:
                        System.out.println(columnOperations.getColumnNames());
                        break;
                    case 5:
                        System.out.println("Fields to filter : ");
                        System.out.println(columnOperations.getColumnNames());
                        System.out.println("ex : name contains abc and price gt 10");
                        sc = new Scanner(System.in);

                        String filterBy = sc.nextLine();

                        selectedList = filterOperations.filter(selectedList, filterBy);
                        List<String> filterColumnList = listOperations.printSelectedList(selectedList);
                        System.out.println("Export to csv? (Y/N)");
                        String filterExport = sc.next();
                        exportCSV(csvUtil, filterExport, selectedList, filterColumnList, "filter_" + filterBy);
                        break;
                    case 6:
                        Set<String> designers = exportOperations.getDesigners(productsFromCSV);
                        csvUtil.writeDesignersToCSV(designers);
                        break;
                    case 7:
                        Map<String, List<Product>> categoryMap = exportOperations.getProductsCategories(productsFromCSV);
                        List<String> columns = new ArrayList<>();
                        Field[] fields = Product.class.getDeclaredFields();
                        for (int i = 0; i < fields.length; i++) {
                            Field f = fields[i];
                            f.setAccessible(true);
                            if (!"category".equals(f.getName())) {
                                columns.add(f.getName());
                            }
                        }
                        for (Map.Entry<String, List<Product>> entry : categoryMap.entrySet()) {
                            csvUtil.writeProductToCSV(entry.getKey(), entry.getValue(), columns);
                        }
                        break;
                }
            }catch(Exception ex){
                System.out.println("Oops, something went wrong");
                System.out.println(ex.getMessage());
            }
        }
    }

    private static void exportCSV(CSVUtil csvUtil, String export, List<Product> selectedList, List<String> columnList, String fileName) {
        if("Y".equalsIgnoreCase(export)) {
            if (columnList.isEmpty()) {
                Field[] fields = Product.class.getDeclaredFields();
                for (int i = 0; i < fields.length; i++) {
                    Field f = fields[i];
                    f.setAccessible(true);
                    columnList.add(f.getName());
                }
            }
            csvUtil.writeProductToCSV(fileName, selectedList,columnList);
        }
    }

    public static ArrayList<String> customSplit(String s)
    {
        ArrayList<String> words = new ArrayList<String>();
        boolean notInsideComma = true;
        int start =0, end=0;
        for(int i=0; i<s.length()-1; i++)
        {
            if(s.charAt(i)==',' && notInsideComma)
            {
                words.add(s.substring(start,i));
                start = i+1;

                while(start<s.length()-1 && s.charAt(start)==',' && s.charAt(i)==',' && notInsideComma){
                    words.add("");
                    start ++;
                    i++;
                }

            }
            else if(s.charAt(i)=='"')
                notInsideComma=!notInsideComma;
        }

        if(s.endsWith(",")){
            words.add(s.substring(start,s.length()-1));
            words.add("");
        }
        else{
            words.add(s.substring(start));
        }
        return words;
    }
}