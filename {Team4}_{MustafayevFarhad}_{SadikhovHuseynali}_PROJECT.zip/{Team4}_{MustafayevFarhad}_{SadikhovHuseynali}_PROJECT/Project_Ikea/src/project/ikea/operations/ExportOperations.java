package project.ikea.operations;

import project.ikea.pojo.Product;

import java.util.*;

public class ExportOperations {

    public Set<String> getDesigners(List<Product> productsFromCSV){
        Set<String> designers = new LinkedHashSet<>();
        for(Product product:productsFromCSV){
            char c1 = product.getDesigner().charAt(0);
            char c2 = product.getDesigner().charAt(1);
            if(!(Character.isDigit(c1) || Character.isDigit(c2))){
                if(product.getDesigner().contains("/")) {
                    String[] designerArr = product.getDesigner().split("/");
                    for(String designer : designerArr){
                        designers.add(designer);
                    }
                }else{
                    designers.add(product.getDesigner());
                }

            }
        }
        return designers;
    }

    public Map<String,List<Product>> getProductsCategories(List<Product> productsFromCSV){
        Map<String,List<Product>> categoryMap = new HashMap<>();
        for(Product product : productsFromCSV){
            if(categoryMap.containsKey(product.getCategory())){
                 List<Product> productList = categoryMap.get(product.getCategory());
                 productList.add(product);
                categoryMap.put(product.getCategory(),productList);
            }else{
                List<Product> productList = new ArrayList<>();
                productList.add(product);
                categoryMap.put(product.getCategory(),productList);
            }
        }
        return categoryMap;
    }
}
