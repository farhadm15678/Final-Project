package project.ikea.operations;

import project.ikea.pojo.Product;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.Array;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class SortOperations {
    Scanner sc = new Scanner(System.in);
    public List<Product> sort(List<Product> productsFromCSV) {
        System.out.println("Sort on field : ");
        String sortBy = sc.next();
        System.out.println("Sort Order (ASC or DESC)");
        String order = sc.next();


        Comparator c= Comparator.comparing(product -> {
            try {
                Field field = product.getClass().getDeclaredField(sortBy);
                field.setAccessible(true);
                return (Comparable) field.get(product);
            } catch (Exception e) {
                throw new RuntimeException("Ooops", e);
            }
        });

        if(order.equalsIgnoreCase("DESC")){
            c = c.reversed();
        }

        productsFromCSV.sort(c);
        return productsFromCSV;

    }

}
