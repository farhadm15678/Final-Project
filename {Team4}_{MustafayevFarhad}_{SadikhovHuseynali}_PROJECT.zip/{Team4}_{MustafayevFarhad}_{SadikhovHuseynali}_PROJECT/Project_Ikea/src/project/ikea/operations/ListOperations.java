package project.ikea.operations;

import project.ikea.pojo.Product;

import java.lang.reflect.Field;
import java.util.*;

public class ListOperations {

    ColumnOperations co = new ColumnOperations();
    Scanner sc = new Scanner(System.in);

    public List<Product> listMenu(List<Product> allProductsFromCSV) {

        System.out.println("a. List randomly selected 20 entities");
        System.out.println("b. List top 20 entities");
        System.out.println("c. List bottom 20 entities");
        System.out.println("d. All entities");

        String op = sc.next();
        List<Product> selectedProducts = new ArrayList<>();
        switch (op) {
            case "a":
                selectedProducts = random20(allProductsFromCSV);
                break;
            case "b":
                selectedProducts = top20(allProductsFromCSV);
                break;
            case "c":
                selectedProducts = bottom20(allProductsFromCSV);
                break;
            case "d":
                selectedProducts = allProductsFromCSV;
        }

        return selectedProducts;
    }

    private List<Product> bottom20(List<Product> allProductsFromCSV) {
        List<Product> products = allProductsFromCSV.subList(allProductsFromCSV.size() - 20, allProductsFromCSV.size());
        return products;
    }

    private List<Product> top20(List<Product> allProductsFromCSV) {
        List<Product> products = allProductsFromCSV.subList(0, 20);
        return products;
    }

    private List<Product> random20(List<Product> allProductsFromCSV) {
        Random rand = new Random();
        List<Product> newList = new ArrayList<>();
        int totalItems = 20;
        for (int i = 0; i < totalItems; i++) {
            int randomIndex = rand.nextInt(allProductsFromCSV.size());
            newList.add(allProductsFromCSV.get(randomIndex));
        }
        return newList;
    }


    public List<Product> listAll(List<Product> productsFromCSV) {
        for (Product p : productsFromCSV) {
            System.out.println(p);
        }
        return productsFromCSV;
    }


    public List<String> printSelectedList(List<Product> selectedList) {
        System.out.println("i. Print All fields of each entity");
        System.out.println("ii. Print Only Selected fields of each entity");
        String op = sc.next();
        List<String> selectedColumns = new ArrayList<>();
        switch (op) {
            case "i":
                printAllFields(selectedList);
                break;
            case "ii":
                selectedColumns = printSelectedFields(selectedList);
                break;
        }
        return selectedColumns;
    }

    private List<String> printSelectedFields(List<Product> selectedList) {
        System.out.println("Select Fields : (comma-separated field names)");
        System.out.println(co.getColumnNames());
        System.out.println();

        String selection = sc.next();
        List<String> printFields = Arrays.asList(selection.split(","));
        try {
            Field[] fields = Product.class.getDeclaredFields();
            for (Product p : selectedList) {
                for (int i = 0; i < fields.length; i++) {
                    Field f = fields[i];
                    f.setAccessible(true);
                    if (printFields.contains(f.getName())) {
                        System.out.print(f.getName() + " = ");
                        System.out.print(f.get(p) + ", ");
                    }
                }
                System.out.println();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return printFields;
    }

    private List<String> printAllFields(List<Product> selectedList) {
        for (Product p : selectedList) {
            System.out.println(p.toString());
        }
        return new ArrayList<String>();
    }
}
