package project.ikea.operations;

import project.ikea.pojo.Product;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FilterOperations {

    ColumnOperations columnOperations = new ColumnOperations();
    Scanner sc = new Scanner(System.in);
    public List<Product> filter(List<Product> productList, String filterBy){
       List<Product> filteredList = new ArrayList();

        String[] filters = filterBy.split("and");
        List<Predicate<Product>> predicates = new ArrayList<>();
        for(String filter : filters){
            String[] filterVO = filter.trim().split(" ");
            String filterKey = filterVO[0];
            String op = filterVO[1];
            String filterValue = filterVO[2];

            try {
               // Field field = null;

                Field field = Product.class.getDeclaredField(filterKey);
                field.setAccessible(true);

                if(field.getType().equals(String.class)){
                    predicates.add(stringFilter(productList, field,op,filterValue));
                }else if(field.getType().equals(boolean.class)){
                    predicates.add(boolFilter(productList, field, op, filterValue));
                }else{
                    predicates.add(numericFilter(productList, field,op, filterValue));
                }
            } catch (NoSuchFieldException e) {
                System.out.println(e.getMessage());
                return null;
            }


        }
        filteredList = productList.stream()
                            .filter(p -> predicates.stream().allMatch(f -> f.test(p)))
                            .collect(Collectors.toList());
        return filteredList;

    }

    private Predicate<Product> boolFilter(List<Product> productList, Field field, String option, String filterValue) {
        boolean filterVal = Boolean.parseBoolean(filterValue);
        Predicate<Product> predicate =
                product -> {
                    try {
                        return field.getBoolean(product) == filterVal;
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }

                };
        return predicate;
    }

    private Predicate<Product> numericFilter(List<Product> productList, Field field, String option, String filterValue) {
        String[] filterArr = filterValue.split(",");
        float filterVal = Float.parseFloat(filterArr[0]);

        Predicate<Product> predicate = null;
        switch (option){
            case "eq":
                    predicate = product -> {
                        try {
                            return field.getFloat(product)==filterVal;
                        } catch (IllegalAccessException e) {
                            throw new RuntimeException(e);
                        }
                    };
                    break;
            case "gt":
                predicate = product -> {
                    try {
                        return field.getFloat(product)>filterVal;
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }
                };
                break;
            case "lt":
                predicate = product -> {
                    try {
                        return field.getFloat(product)<filterVal;
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }
                };
                break;
            case "ge":
                predicate = product -> {
                    try {
                        return field.getFloat(product)>=filterVal;
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }
                };
                break;
            case "le":
                predicate = product -> {
                    try {
                        return field.getFloat(product)<=filterVal;
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }
                };
                break;

            case "bt":
                float filterVal2 = Float.parseFloat(filterArr[1]);
                predicate = product -> {
                    try {
                        return field.getFloat(product)>filterVal && field.getFloat(product)<filterVal2;
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }
                };
                break;
            case "null":
                predicate = product -> {
                    try {
                        return field.getFloat(product) == 0;
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }
                };
                break;
        }
        return predicate;
    }

    private Predicate<Product> stringFilter(List<Product> productList, Field field, String option, String filterValue) {
        Predicate<Product> predicate;
        if(option.equals("contains")){

            String searchValue = filterValue;
            predicate =
                    product -> {
                        try {
                            return String.valueOf(field.get(product)).toLowerCase().contains(searchValue.toLowerCase());
                        } catch (IllegalAccessException e) {
                            throw new RuntimeException(e);
                        }

                    };

        }else{
            predicate =
                    product -> {
                        try {
                            return (field.get(product) == null || String.valueOf(field.get(product)).equals(""));
                        } catch (IllegalAccessException e) {
                            throw new RuntimeException(e);
                        }

                    };
            }
        return predicate;
    }
}
