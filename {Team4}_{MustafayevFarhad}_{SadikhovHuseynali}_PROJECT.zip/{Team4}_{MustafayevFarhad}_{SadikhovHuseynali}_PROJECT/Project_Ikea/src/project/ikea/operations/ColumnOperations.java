package project.ikea.operations;

import project.ikea.pojo.Product;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class ColumnOperations {

    public List<String> getColumnNames(){
        List<String> columns = new ArrayList<>();
        Field[] fields = Product.class.getDeclaredFields();
        for (int i = 0; i < fields.length; i++) {
            columns.add(fields[i].getName());
        }
        return columns;
    }
}
