package project.ikea.operations;

import project.ikea.pojo.Product;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class SearchOperations {

    ColumnOperations co = new ColumnOperations();
    Scanner sc = new Scanner(System.in);

    public List<Product> search(List<Product> productList, String searchField, String searchValue) {
        List<Product> searchedProducts = new ArrayList<>();

        try {
            Field field = Product.class.getDeclaredField(searchField);
            field.setAccessible(true);
            searchedProducts = productList.stream()
                    .filter(
                            product -> {
                                try {
                                    return String.valueOf(field.get(product)).toLowerCase().contains(searchValue.toLowerCase());
                                } catch (IllegalAccessException e) {
                                    throw new RuntimeException(e);
                                }

                            }

                    )
                    .collect(Collectors.toList());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return searchedProducts;
    }
}
