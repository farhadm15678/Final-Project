package project.ikea.pojo;

public class Product {
    private int id;
    private int itemId;
    private String name;
    private String category;
    private float price;
    private String oldPrice;
    private boolean sellableOnline;
    private String link;
    private boolean otherColors;
    private String shortDescription;
    private String designer;
    private float depth;
    private float height;
    private float width;

    public Product() {
    }

    public Product(int id, int itemId, String name, String category, float price, String oldPrice, boolean sellableOnline, String link, boolean otherColors, String shortDescription, String designer, float depth, float height, float width) {
        this.id = id;
        this.itemId = itemId;
        this.name = name;
        this.category = category;
        this.price = price;
        this.oldPrice = oldPrice;
        this.sellableOnline = sellableOnline;
        this.link = link;
        this.otherColors = otherColors;
        this.shortDescription = shortDescription;
        this.designer = designer;
        this.depth = depth;
        this.height = height;
        this.width = width;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getOldPrice() {
        return oldPrice;
    }

    public void setOldPrice(String oldPrice) {
        this.oldPrice = oldPrice;
    }

    public boolean isSellableOnline() {
        return sellableOnline;
    }

    public void setSellableOnline(boolean sellableOnline) {
        this.sellableOnline = sellableOnline;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public boolean getOtherColors() {
        return otherColors;
    }

    public void setOtherColors(boolean otherColors) {
        this.otherColors = otherColors;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getDesigner() {
        return designer;
    }

    public void setDesigner(String designer) {
        this.designer = designer;
    }

    public float getDepth() {
        return depth;
    }

    public void setDepth(float depth) {
        this.depth = depth;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    @Override
    public String toString() {
        return  "id=" + id +
                ", itemId=" + itemId +
                ", name='" + name + '\'' +
                ", category='" + category + '\'' +
                ", price=" + price +
                ", oldPrice=" + oldPrice +
                ", sellableOnline=" + sellableOnline +
                ", link='" + link + '\'' +
                ", otherColors='" + otherColors + '\'' +
                ", shortDescription='" + shortDescription + '\'' +
                ", designer='" + designer + '\'' +
                ", depth=" + depth +
                ", height=" + height +
                ", width=" + width
                ;

    }
}
