package project.ikea.pojo.util;

import project.ikea.pojo.Product;

import java.io.*;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CSVUtil {
    private static final String CSV_SEPARATOR = ",";


    /*
     * Method to read the records from provided csv file and performing processing operations
     */
    public List<Product> readCSV(String fileName) {
        ProductUtil productUtil= new ProductUtil();

        List<Product> products = new ArrayList<>();
        Path pathToFile = Paths.get(fileName);

        // create an instance of BufferedReader
        // using try with resource, Java 7 feature to close resources
        try (BufferedReader br = Files.newBufferedReader(pathToFile)) {

            // read the first line from the text file
            String header = br.readLine();

            String line = br.readLine();
            // loop until all lines are read
            while (line != null) {

                // use string.split to load a string array with the values from
                // each line of
                // the file, using a comma as the delimiter
                // String[] attributes = line.split(","); // wont work, as there are few records with , inside ""

                //splitting the data while taking care of commas
                //line = removeNewLines(line);
                //line =	line.replaceAll("/\\r?\\n|\\r/");
//                while(line !=null && !line.endsWith("\"")) {
//                    line = line.concat(br.readLine());
//                }
                ArrayList<String> attributesArr = customSplit(line);
                String[] attributes = attributesArr.toArray(new String[attributesArr.size()]);
               // String[] attributes = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
                //perform processing operations, and return the required list
                Product product = productUtil.createProduct(attributes);

                //just for testing -  printing the records form excel to console
                //System.out.println(product);
                // adding book into ArrayList
                products.add(product);

                // read next line before looping
                // if end of file reached, line would be null
                line = br.readLine();
            }

        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

        return products;
    }

    public static String removeNewLines(String input) {
        Matcher matcher = Pattern.compile("\"([^\"]*[\n\r].*?)\"").matcher(input);
        Pattern patternRemoveLineBreak = Pattern.compile("[\n\r]");

        String result = input;
        while(matcher.find()) {
            String quoteWithLineBreak = matcher.group(1);
            String quoteNoLineBreaks = patternRemoveLineBreak.matcher(quoteWithLineBreak).replaceAll(" ");
            result = result.replaceFirst(quoteWithLineBreak, quoteNoLineBreaks);
        }
        return result;
    }

    public static ArrayList<String> customSplit(String s)
    {
        ArrayList<String> words = new ArrayList<String>();
        boolean notInsideComma = true;
        int start =0, end=0;
        for(int i=0; i<s.length()-1; i++)
        {
            if(s.charAt(i)==',' && notInsideComma)
            {
                words.add(s.substring(start,i));
                start = i+1;

                while(start<s.length()-1 && s.charAt(start)==',' && s.charAt(i)==',' && notInsideComma){
                    words.add("");
                    start ++;
                    i++;
                }

            }
            else if(s.charAt(i)=='"')
                notInsideComma=!notInsideComma;
        }

        if(s.endsWith(",")){
            words.add(s.substring(start,s.length()-1));
            words.add("");
        }
        else{
            words.add(s.substring(start));
        }
        return words;
    }

    public void writeDesignersToCSV(Set<String> designers) {

        try {

            //creating new designers.csv file
            BufferedWriter bw = new BufferedWriter(
                    new OutputStreamWriter(new FileOutputStream("designers.csv"), "UTF-8"));

            //headers
            String[] headers = { "designer"};
            StringBuffer heading = new StringBuffer();
            for (String header : headers) {
                heading.append(header).append(CSV_SEPARATOR);
            }
            bw.write(heading.toString());
            bw.newLine();

            //data
            for (String designer : designers) {
                StringBuffer line = new StringBuffer();
                line.append(designer).append(CSV_SEPARATOR);
                bw.write(line.toString());
                bw.newLine();
            }
            bw.flush();
            bw.close();
        } catch (UnsupportedEncodingException e) {
            System.out.println("UnsupportedEncodingException : " + e);
        } catch (FileNotFoundException e) {
            System.out.println("File not found : " + e);
        } catch (IOException e) {
            System.out.println("IO Exception : " + e);
        }

    }

    public void writeProductToCSV(String fileName,List<Product> productList, List<String> columns) {

        try {

            //creating new results.csv file
            BufferedWriter bw = new BufferedWriter(
                    new OutputStreamWriter(new FileOutputStream(fileName+".csv"), "UTF-8"));

            //header
            String[] headers = columns.toArray(new String[0]);

            StringBuffer heading = new StringBuffer();
            for (String header : headers) {
                heading.append(header).append(CSV_SEPARATOR);

            }
            bw.write(heading.toString());
            bw.newLine();


            Field[] fields = Product.class.getDeclaredFields();
            //data
            for (Product product : productList) {
                StringBuffer line = new StringBuffer();
                for (int i = 0; i < fields.length; i++) {
                    Field f = fields[i];
                    f.setAccessible(true);
                    if (columns.contains(f.getName())) {
                        line.append(f.get(product)).append(CSV_SEPARATOR);
                    }
                }
                bw.write(line.toString());
                bw.newLine();
            }
            bw.flush();
            bw.close();
        } catch (UnsupportedEncodingException e) {
            System.out.println("UnsupportedEncodingException : " + e);
        } catch (FileNotFoundException e) {
            System.out.println("File not found : " + e);
        } catch (IOException e) {
            System.out.println("IO Exception : " + e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }

    }
}
