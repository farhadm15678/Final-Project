package project.ikea.pojo.util;

import project.ikea.pojo.Product;

public class ProductUtil {

    public Product createProduct(String[] metadata) {

        int id = Integer.parseInt(metadata[0]);
        int itemId = Integer.parseInt(metadata[1]);
        String name = metadata[2];
        String category = metadata[3];
        float price = Float.parseFloat(metadata[4]);
        String oldPrice =metadata[5];
//        float oldPrice = 0.0f;
        boolean sellable_online = false;
        if(metadata[6].equalsIgnoreCase("TRUE")){
            sellable_online=true;
        }

        String link = metadata[7];
        boolean otherColors = false;
        if(metadata[8].equalsIgnoreCase("Yes")){
            otherColors = true;
        }

        String shortDescription = metadata[9];
        String designer = metadata[10];
        float depth = metadata[11].isEmpty()?0f:Float.parseFloat(metadata[11]);
        float height = metadata[12].isEmpty()?0f:Float.parseFloat(metadata[12]);
        float width =metadata[13].isEmpty()?0f: Float.parseFloat(metadata[13]);


        return new Product(id, itemId, name, category, price, oldPrice, sellable_online, link, otherColors, shortDescription, designer, depth, height, width);

    }
}
